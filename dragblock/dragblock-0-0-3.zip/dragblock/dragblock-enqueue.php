<?php
if ( ! defined( 'ABSPATH' ) ) exit;
/**
 * Documents
 * https://jasonyingling.me/enqueueing-scripts-and-styles-for-gutenberg-blocks/
 */

/**
 * Documents:
 * https://github.com/WordPress/gutenberg/issues/23223
 */
global $dragblock_save_css;
$dragblock_save_css = '';
global $dragblock_save_js;
$dragblock_save_js = '';
global $dragblock_theme_json;
global $dragblock_default_json;
global $dragblock_user_json;



/**
 * 
 */
function dragblock_enqueue_register($handle, $path, $dep = null)
{
    // enqueue script
    if (strpos($path, '.js')) {
        wp_register_script(
            $handle,
            dragblock_url($path),
            $dep,
            DRAGBLOCK_VERSION,
            true
        );
    }
    // enqueue style
    else {
        wp_register_style(
            $handle,
            dragblock_url($path),
            $dep,
            DRAGBLOCK_VERSION
        );
    }
}
/**
 * @param {string} $handle id of the script/style
 * @param {string} $path full path to the file, including the extension
 */
function dragblock_enqueue($handle, $path, $dep = null)
{
    dragblock_enqueue_register($handle, $path, $dep);
    // enqueue script
    if (strpos($path, '.js')) {
        wp_enqueue_script($handle);
    }
    // enqueue style
    else {
        wp_enqueue_style($handle);
    }
}





/**
 * Render custom css for any block that has inlineStyle attribute
 * $block = array(5) {
  ["blockName"]=> string(21) "dragblock/wrapper"
  ["attrs"]=> array(2) {}
  ["innerBlocks"]=>array(0) {}
  ["innerHTML"]=>string(113) ""
 */
// add_filter( 'render_block', 'dragblock_save_css', 10, 2 );
// function dragblock_save_css( $block_content, $block ) {    

//     if (empty($block['attrs']['dragBlockCSS'])) {        
//         return $block_content;
//     }    

//     global $dragblock_save_css;
//     $dragblock_save_css .= $block['attrs']['dragBlockCSS'];

// 	return $block_content;
// }


/**
 * GET custom CSS/JS for any block that has inlineScript attribute
 * $block = array(5) {  
 */
// add_filter( 'render_block', 'dragblock_save_js', 10, 2 );
// function dragblock_save_js( $block_content, $block ) {    

//     if (empty($block['attrs']['dragBlockJS'])) {        
//         return $block_content;
//     }    

//     global $dragblock_save_js;
//     $dragblock_save_js .= $block['attrs']['dragBlockJS'];

// 	return $block_content;
// }
/**
 * We have to use 'render_block' here because native core blocks like navigation-link
 * will have style attribute only in the rendering block
 */
global $dragblock_uids;
$dragblock_uids = array();
add_filter('render_block', 'dragblock_enqueue_get_saved_assets', 10, 2);
function dragblock_enqueue_get_saved_assets($block_content, $block)
{
    if ($block['blockName'] == 'core/null' ||
        empty($block['attrs']['dragBlockClientId']) ||
        (empty($block['attrs']['dragBlockCSS']) && empty($block['attrs']['dragBlockJS']))
    ) {
        return $block_content;
    }

    global $dragblock_uids;

    /**     
     * We added $block['blockName'] as a prefix because some block like core/post-template
     * will have a clone as core/null which have the same attribute but will not be rendered
     */
    $uidAccessKey = $block['blockName'] . $block['attrs']['dragBlockClientId'];

    /*        
    Some blocks repeat themselves in block templates, ex: Comment Template block
    so this is to prevent collect the same block two times
    which will increase the count of $dragblock_uids incorrectly        
    */
    if (!empty($dragblock_uids[$uidAccessKey])) {
        return $block_content;
    }
    $shortClass = 'uid'. count($dragblock_uids);
    $shortSelector = '.uid' . count($dragblock_uids);
    

    /**    
     * We have to override some core selectors because WP have inline 
     * core CSS that override our uid selector
     * Ex: .wp-block-post-template will override .uidx
     * even when  .uidx stays under the .wp-block-post-template
     */
    if ($block['blockName'] === 'core/post-template') {
        $shortSelector = '.wp-block-post-template' . $shortSelector;
    }

    if (!empty($block['attrs']['dragBlockCSS'])) {
        $block['attrs']['dragBlockCSS'] =
            str_replace(
                '[data-dragblock-client-id="' . $block['attrs']['dragBlockClientId'] . '"]',
                $shortSelector,
                $block['attrs']['dragBlockCSS']
            );
        // this line should be here to insure the id you replaced matches with the id
        // you saved in the uids        

        global $dragblock_save_css;
        $dragblock_save_css .= $block['attrs']['dragBlockCSS'];
    }
    if (!empty($block['attrs']['dragBlockJS'])) {

        $block['attrs']['dragBlockJS'] =
            str_replace(
                '[data-dragblock-client-id="' . $block['attrs']['dragBlockClientId'] . '"]',
                $shortSelector,
                $block['attrs']['dragBlockJS']
            );
        global $dragblock_save_js;
        $dragblock_save_js .= $block['attrs']['dragBlockJS'];
    }

    
    $dragblock_uids[$uidAccessKey] = $shortClass;

    return $block_content;
}


/**
 * Get json data from theme to replace vairables in the blocks scripts
 */
/**
 * Get theme default data
 */
add_filter('wp_theme_json_data_theme', 'dragblock_enqueue_wptheme_theme_json', 10);
function dragblock_enqueue_wptheme_theme_json($json)
{
    global $dragblock_theme_json;
    $dragblock_theme_json = $json->get_data();
    return $json;
}

/**
 * Get core default data
 */
add_filter('wp_theme_json_data_default', 'dragblock_enqueue_wptheme_default_json', 10);
function dragblock_enqueue_wptheme_default_json($json)
{
    global $dragblock_default_json;
    $dragblock_default_json = $json->get_data();
    
    return $json;
}

/**
 * Get core default data
 */
add_filter('wp_theme_json_data_user', 'dragblock_enqueue_wptheme_user_json', 10);
function dragblock_enqueue_wptheme_user_json($json)
{
    global $dragblock_user_json;
    $dragblock_user_json = $json->get_data();
    
    return $json;
}

/**
 * FRONT END
 * collect all scripts and styles for front-end display
 */
// add_action( 'wp_enqueue_scripts', 'dragblock_enqueue_front_end' );
add_action('enqueue_block_assets', 'dragblock_enqueue_front_end');
function dragblock_enqueue_front_end()
{
    // @fix: why this also be enqueued in the back-end editor (not the iframe)?
    dragblock_enqueue('dragblock-app-front', 'build/applications/front/index.js', array('jquery'));

    // if allow users to modify the default styles, then just need to load an empty css
    if (DRAG_BLOCK_CUSTOM_DEFAULT_STYLE) {
        dragblock_enqueue('dragblock-app-front', 'build/applications/front/index.css');
    } else {
        dragblock_enqueue('dragblock-app-front', 'build/applications/front/style-index.css');
    }


    global $dragblock_save_css;
    global $dragblock_save_js;

    // replace variables
    global $dragblock_theme_json;
    global $dragblock_default_json;
    global $dragblock_user_json;

    
    // update color variables
    // we have to do this on the front-end in order to allow users set the opacity for the orginal color in the back-end
    // !the 'theme' property is added automatically via the $json->get_data(); of wordpress
    ////////////////////////////////////////////////////////////////////////
    // If Users changed even one color that predefined in the theme.json, 
    // the system will return a whole settings/color/palette/theme in wp_theme_json_data_user
    if (
        !empty($dragblock_user_json['settings']['color']['palette']['theme'])
    ) {
        $dragblock_theme_json['settings']['color']['palette']['theme'] = $dragblock_user_json['settings']['color']['palette']['theme'];
    }

    ////////////////////////////////////////////////////////////////////////
    // Here are the colors added by users themselves    
    if (
        !empty($dragblock_user_json['settings']['color']['palette']['custom'])
    ) {
        $dragblock_theme_json['settings']['color']['palette']['theme'] = array_merge($dragblock_theme_json['settings']['color']['palette']['theme'], $dragblock_user_json['settings']['color']['palette']['custom']);
    }

    if (!empty($dragblock_theme_json['settings']['color']['palette']['theme'])) {
        foreach ($dragblock_theme_json['settings']['color']['palette']['theme'] as $color) {
            // perfect match
            $dragblock_save_css = str_replace(
                '{c=' . $color['slug'] . '}',
                $color['color'],
                $dragblock_save_css
            );

            // without alpha match
            $dragblock_save_css = str_replace(
                '{c=' . $color['slug'] . '@}',
                substr($color['color'], 0, 7),
                $dragblock_save_css
            );
        }
    }

    if (!empty($dragblock_default_json['settings']['color']['palette']['default'])) {
        foreach ($dragblock_default_json['settings']['color']['palette']['default'] as $color) {
            // perfect match
            $dragblock_save_css = str_replace(
                '{c=' . $color['slug'] . '}',
                $color['color'],
                $dragblock_save_css
            );

            // without alpha match
            $dragblock_save_css = str_replace(
                '{c=' . $color['slug'] . '@}',
                substr($color['color'], 0, 7),
                $dragblock_save_css
            );
        }
    }

    /**
    Synchronize with the system settings
     */
    // button font-family for custom drag block button    
    // if (!empty($dragblock_user_json['styles']['elements']['button']['typography']['fontFamily'])) {        
    //     $font_family = $dragblock_user_json['styles']['elements']['button']['typography']['fontFamily'];
    //     $font_family = str_replace('|', '--', $font_family);
    //     $font_family = str_replace('var:preset', '--wp--preset', $font_family);
    //     $dragblock_save_css .= 'button.wp-block-dragblock-wrapper {font-family: var('.$font_family.')';
    // } 
    

    /// add to output css
    if ($dragblock_save_css) {
        wp_add_inline_style('dragblock-app-front', $dragblock_save_css);
    }
    if ($dragblock_save_js) {
        wp_add_inline_script('dragblock-app-front', $dragblock_save_js, 'after');
    }
    if (strpos($dragblock_save_css, 'animation-name') !== false) {
        dragblock_enqueue('dragblock-app-animate', 'assets/css/animate.min.css');
    }

    ////////////////////////////////
    // DragBlock Form Protection
    wp_add_inline_script('dragblock-app-front', 'var DRAG_BLOCK_FORM_NONCE_ACTION ="' . esc_js(wp_create_nonce('dragblock/form-nonce-action')) . '"', 'before');

    // this is submitted by a js bot (to fast in filling)
    // Start the session
    if (!session_id()) {
        session_start();
    }

    // Generate a unique ID
    $unique_id = uniqid();

    // Store the ID in the session
    $_SESSION[$unique_id] = time();


    wp_add_inline_script('dragblock-app-front', 'var DRAG_BLOCK_FORM_SESSION_TOKEN ="' . $unique_id . '"', 'before'); 
}


/**
 * IN IFRAME
 * all STYLES for modifying elements in editor iframe, including blocks
 */
add_action('after_setup_theme', 'dragblock_enqueue_editor_iframe', 100);
function dragblock_enqueue_editor_iframe()
{
    add_editor_style(dragblock_url('assets/css/animate.min.css'));

    // if allow users to modify the default styles, then don't need to load this for editor
    // because the custom css will be loaded to the editor automatically via the style.css in theme.json
    if (!DRAG_BLOCK_CUSTOM_DEFAULT_STYLE) {
        add_editor_style(dragblock_url('build/applications/front/style-index.css'));
    }
}


/**
 * BACK END - EDITOR
 * all scripts and styles for modifying editor UI, ex: settings, controls, toolbars ... but the blocks
 */
add_action('enqueue_block_editor_assets', 'dragblock_enqueue_editor');
function dragblock_enqueue_editor()
{
    dragblock_enqueue('dragblock-app-back', 'build/applications/back/index.js', array('jquery'));
    dragblock_enqueue('dragblock-app-back', 'build/applications/back/style-index.css');
    dragblock_enqueue('dragblock-app-animate', 'assets/css/animate.min.css');
    // dragblock_enqueue('dragblock-app-back-import', 'build/applications/back/index.css'); 

    wp_add_inline_script(
        'dragblock-app-back',
        '
    var DRAG_BLOCK_BLANK_DEMO_IMG="' . plugins_url('assets/images/demo/blank.png', __FILE__) . '";    
    var DRAGBLOCK_SITE_LOCALE="' . DRAGBLOCK_SITE_LOCALE . '";
    ',
        'before'
    );
}

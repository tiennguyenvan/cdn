<?php
if ( ! defined( 'ABSPATH' ) ) exit;
class DragBlock_React_App {
	public static function bootstrap() {
		// Load the required WordPress packages.
		// Automatically load imported dependencies and assets version.
		$asset_file = include DRAGBLOCK_PATH . 'build/applications/admin/fonts/index.asset.php';
		
		// Enqueue CSS dependencies of the scripts included in the build.
		foreach ( $asset_file['dependencies'] as $style ) {
			wp_enqueue_style( $style );
		}

		// Enqueue CSS of the app
		wp_enqueue_style( 'dragblock-font-library-app', dragblock_url( 'build/applications/admin/fonts/index.css'), array(), $asset_file['version'] );

		// Load our app.js.
		array_push( $asset_file['dependencies'], 'wp-i18n' );
		wp_enqueue_script( 'dragblock-font-library-app', dragblock_url( 'build/applications/admin/fonts/index.js'), $asset_file['dependencies'], $asset_file['version'] );

		// Set google fonts json file url.
		wp_localize_script(
			'dragblock-font-library-app',
			'dragBlockFontLib', 
			array(
				'googleFontsDataUrl' => dragblock_url( 'assets/google-fonts/fallback-fonts-list.json' ),
				'adminUrl'           => admin_url(),
				// 'uploadUrl'           => get_stylesheet_directory_uri(),
				'uploadUrl'           => DRAGBLOCK_UPLOAD_URL,
				'adminMenuSlug' => DRAGBLOCK_ADMIN_MENU_SLUG,
				'fontLibSlug' => DRAGBLOCK_FONT_LIB_SLUG
			)
		);
	}
}
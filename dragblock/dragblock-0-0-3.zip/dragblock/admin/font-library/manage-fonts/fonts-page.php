<?php
if ( ! defined( 'ABSPATH' ) ) exit;
require_once( dirname( __DIR__ ) . '/class-react-app.php' );

class DragBlock_Fonts_Page {
	public static function manage_fonts_admin_page() {
		DragBlock_React_App::bootstrap();

		// $theme_name = wp_get_theme()->get( 'Name' );

		// $theme_data          = WP_Theme_JSON_Resolver::get_theme_data();
		// $theme_settings      = $theme_data->get_settings();
		// $font_families = isset( $theme_settings['typography']['fontFamilies']['theme'] ) ? $theme_settings['typography']['fontFamilies']['theme'] : array();
		$font_families = get_option(DRAGBLOCK_FONT_LIB_SLUG, array());

		// This is only run when Gutenberg is not active because WordPress core does not include WP_Webfonts class yet. So we can't use it to load the font asset styles.
		// See the comments here: https://github.com/WordPress/WordPress/blob/88cee0d359f743f94597c586febcc5e09830e780/wp-includes/script-loader.php#L3160-L3186
		// TODO: remove this when WordPress core includes WP_Webfonts class.
		if ( class_exists( 'WP_Webfonts' ) !== true ) {
			$font_assets_stylesheet = dragblock_render_font_styles( $font_families );
			wp_register_style( 'dragblock-font-library', false );
			wp_add_inline_style( 'dragblock-font-library', $font_assets_stylesheet );
			wp_enqueue_style( 'dragblock-font-library' );
		}

		$fonts_json        = wp_json_encode( $font_families );
		$fonts_json_string = preg_replace( '~(?:^|\G)\h{4}~m', "\t", $fonts_json );

		?>
		<p name="dragblock-font-library-json" id="dragblock-font-library-json" class="hidden"><?php echo esc_html($fonts_json_string); ?></p>
		<div id="dragblock-font-library-app"></div>
		<input type="hidden" name="nonce" id="nonce" value="<?php echo esc_attr(wp_create_nonce( 'dragblock_font_library' )); ?>" />
		<?php
	}
}

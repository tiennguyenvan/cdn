<?php
if ( ! defined( 'ABSPATH' ) ) exit;

define('DRAGBLOCK_ADMIN_MENU_SLUG', 'dragblockAdminMenu'); // 18 char
// register the plugin page
add_action('admin_menu', 'dragblock_admin_main_menu', 1);
function dragblock_admin_main_menu()
{

	if ( !empty ( $GLOBALS['admin_page_hooks'][DRAGBLOCK_ADMIN_MENU_SLUG] ) ) {
		return;
	}

	add_menu_page(
		__('DragBlock Welcome Page', 'dragblock'),
		__('DragBlock', 'dragblock'),
		'manage_options',
		DRAGBLOCK_ADMIN_MENU_SLUG,
		'dragblock_admin_main_menu_page',
		plugins_url('dragblock/assets/images/brands/favicon-16x16.png'),
		6
	);	
}

// define the main menu page callback function
function dragblock_admin_main_menu_page()
{
	// Redirect users to the form entry page
    
	// // display the content of the default plugin page
	echo '<h1>' . __('Welcome to DragBlock', 'dragblock') . '</h1>';
	echo '<p>' . __('If you have any suggestion, please send to <a href="mailto:contact@dragblock.com"><strong>contact@dragblock.com</strong></a>. Thank you very much.', 'dragblock') . '</p>';
}

/**
 * 
 */
add_action( 'admin_enqueue_scripts', 'dragblock_admin_enqueue_scripts' );
function dragblock_admin_enqueue_scripts() {
    dragblock_enqueue('dragblock-app-admin', 'build/applications/admin/index.js', array('jquery'));
    dragblock_enqueue('dragblock-app-admin', 'build/applications/admin/style-index.css');
}

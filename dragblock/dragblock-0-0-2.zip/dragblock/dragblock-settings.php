<?php
if ( ! defined( 'ABSPATH' ) ) exit;

// Set more reasonable default thumbnail size
add_action('after_setup_theme', 'dragblock_default_image_sizes');
function dragblock_default_image_sizes()
{
    // this is the default thumbnail sizes of wordpress
    // we need to improve it to match with the modern designs
    if (
        '150' === get_option('thumbnail_size_w') &&
        '150' === get_option('thumbnail_size_h') &&
        '300' === get_option('medium_size_w') &&
        '300' === get_option('medium_size_h') &&
        '1024' === get_option('large_size_w') &&
        '1024' === get_option('large_size_h') &&
        '1' === get_option('thumbnail_crop')
    ) {
        update_option('thumbnail_size_w', '420');
        update_option('thumbnail_size_h', '9999');
        update_option('medium_size_w', '800');
        update_option('medium_size_h', '9999');
        update_option('large_size_w', '1030');
        update_option('large_size_h', '9999');
        update_option('thumbnail_crop', '');
    }
}

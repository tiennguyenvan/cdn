<?php
if ( ! defined( 'ABSPATH' ) ) exit;



// global $dragBlockQueries;
// global $dragBlockCurListQueryId;
// global $dragBlockCurListQueryIdItem;
// $dragBlockQueries = null;
// $dragBlockCurListQueryId = null;
// $dragBlockCurListQueryIdItem = null;

/**
 * 
 */
function dragblock_get_current_list_query_id()
{
    global $dragBlockQueries;
    global $dragBlockCurListQueryId;
    global $dragBlockCurListQueryIdItem;
    // var_dump($dragBlockCurListQueryId, $dragBlockQueries[$dragBlockCurListQueryId], $dragBlockCurListQueryIdItem);

    if ($dragBlockCurListQueryIdItem === null) {
        $dragBlockCurListQueryIdItem = 0;
    }

    $item_id = null;

    if (
        $dragBlockCurListQueryId !== null &&
        !empty($dragBlockQueries) &&
        !empty($dragBlockQueries[$dragBlockCurListQueryId]) &&
        !empty($dragBlockQueries[$dragBlockCurListQueryId][$dragBlockCurListQueryIdItem])
    ) {
        $item_id = $dragBlockQueries[$dragBlockCurListQueryId][$dragBlockCurListQueryIdItem];
    }

    return $item_id;
}

/**
 * 
 */
add_shortcode('dragblock.post.snippet', 'dragblock_shortcode_post_snippet');
function dragblock_shortcode_post_snippet($attrs)
{

    $post_id = dragblock_get_current_list_query_id();

    if ($post_id === null) {
        return '';
    }

    // Get the post excerpt if it exists, or the first paragraph of the post content
    $snippet = '';
    
    $len = !empty($attrs['len']) ? sanitize_text_field($attrs['len']) : '55';
    if (empty($len) || !is_numeric($len)) {
        $len = '55';
    }
    $len = (int) $len;
    if (has_excerpt($post_id)) {
        $snippet = get_the_excerpt($post_id);
    } else {
        $snippet = get_the_content(null, false, $post_id);
    }
    if (strlen($snippet) > $len) {
        $snippet = wp_trim_words($snippet, $len, '...');
    }

    return $snippet;
}

add_shortcode('dragblock.post.title', 'dragblock_shortcode_post_title');
function dragblock_shortcode_post_title($attrs)
{

    $post_id = dragblock_get_current_list_query_id();

    if ($post_id === null) {
        return '';
    }
    return get_the_title($post_id);
}

add_shortcode('dragblock.post.url', 'dragblock_shortcode_post_url');
function dragblock_shortcode_post_url($attrs)
{

    $post_id = dragblock_get_current_list_query_id();

    if ($post_id === null) {
        return 'javascript:void(0)';
    }
    return get_the_permalink($post_id);
}

add_shortcode('dragblock.post.image.src', 'dragblock_shortcode_post_image_src');
function dragblock_shortcode_post_image_src($attrs)
{
    $size = isset($attrs['size']) ? sanitize_text_field($attrs['size']) : 'full';

    $post_id = dragblock_get_current_list_query_id();

    if ($post_id === null) {
        return 'data:image/gif;base64,R0lGODlhAQABAAD/ACwAAAAAAQABAAACADs=';
    }



    // Step 1: Check if post has a featured image
    if (has_post_thumbnail($post_id)) {
        $image_url = get_the_post_thumbnail_url($post_id, $size);

        return $image_url;
    }

    // Step 2: Check if post has an image in the content
    $content = get_post_field('post_content', $post_id);
    if ($content) {
        $doc = new DOMDocument();
        @$doc->loadHTML($content);
        $img_tags = $doc->getElementsByTagName('img');
        if (count($img_tags) > 0) {

            $image_url = $img_tags[0]->getAttribute('src');

            return $image_url;
        }


        // Step 3: Check if post has any embedded video
        $pattern = '/<iframe.*?src="(https?:\/\/www\.youtube\.com\/embed\/([\w-]+))".*?><\/iframe>/i';
        preg_match($pattern, $content, $matches);
        if (count($matches) > 0) {
            $video_id = $matches[2];
            $image_url = 'https://img.youtube.com/vi/' . $video_id . '/hqdefault.jpg';

            return $image_url;
        }
    }



    // Step 4: Return placeholder image
    // No thumbnail found, return default placeholder image
    return 'data:image/gif;base64,R0lGODlhAQABAAD/ACwAAAAAAQABAAACADs=';

    // $images_dir = array(
    //     'AI', 'cypto', 'cuisine', 'decor', 'travel'
    // );
    // // $images = glob($images_dir . '*.jpg'); // assuming images are in jpg format
    // $images = array();
    // foreach ($images_dir as $dir) {
    //     for ($i = 1; $i <= 10; $i++) {
    //         array_push($images, $dir . '/' . substr('00' . $i, 0, 3));
    //     }
    // }

    // $rand_index = array_rand($images);
    // $image_url = plugins_url('assets/images/demo/' . $images[$rand_index], __FILE__);

    // return $image_url;
}

add_shortcode('dragblock.post.image.srcset', 'dragblock_shortcode_post_image_srcset');
function dragblock_shortcode_post_image_srcset($attrs)
{
    $post_id = dragblock_get_current_list_query_id();

    if ($post_id === null || !has_post_thumbnail($post_id)) {
        return '';
    }

    // Step 1: Check if post has a featured image

    $image_id = get_post_thumbnail_id($post_id);
    $image_srcset = wp_get_attachment_image_srcset($image_id);
    return $image_srcset;
}

/**
 * No longer need too use because user need to input their own sizes
 */
add_shortcode('dragblock.post.image.sizes', 'dragblock_shortcode_post_image_sizes');
function dragblock_shortcode_post_image_sizes($attrs)
{
    $size = isset($attrs['size']) ? sanitize_text_field($attrs['size']) : 'full';

    // takes up to 100% of the screen width
    if ('full' === $size) {
        return '';
    }

    // takes up to 75% of the screen width
    if ('large' === $size) {
        return '75vw';
        // return '(min-width: 0px) 80vw, 80vw';
    }
    // takes up to 50% of the screen width
    if ('medium' === $size) {
        return '50vw';
        // return '(min-width: 0px) 60vw, 60vw';
    }
    // takes up to 25% of the screen width
    if ('thumbnail' === $size) {
        return '25vw';
        // return '(min-width: 0px) 40vw, 40vw';
    }
}


add_shortcode('dragblock.post.date', 'dragblock_shortcode_post_date');
function dragblock_shortcode_post_date($attrs)
{
    $post_id = dragblock_get_current_list_query_id();

    if ($post_id === null) {
        return '';
    }


    // Get the post date
    $post_date = get_post_field('post_date', $post_id);

    // Get the date format from site settings
    $date_format = get_option('date_format');

    // Change the date format
    $formatted_date = date_i18n($date_format, strtotime($post_date));

    // Output the formatted date
    return $formatted_date;
}

add_shortcode('dragblock.post.author.url', 'dragblock_shortcode_post_author_url');
function dragblock_shortcode_post_author_url($attrs)
{
    $post_id = dragblock_get_current_list_query_id();

    if ($post_id === null) {
        return '';
    }
    // Get the author ID of the post
    $author_id = get_post_field('post_author', $post_id);

    // Get the author link
    $author_url = get_author_posts_url($author_id);

    // Output the author link
    return esc_url($author_url);
}

add_shortcode('dragblock.post.author.name', 'dragblock_shortcode_post_author_name');
function dragblock_shortcode_post_author_name($attrs)
{
    $post_id = dragblock_get_current_list_query_id();

    if ($post_id === null) {
        return '';
    }
    // Get the author ID of the post
    $author_id = get_post_field('post_author', $post_id);

    // Get the author name
    $author_name = get_the_author_meta('display_name', $author_id);

    // Output the author name
    return $author_name;
}

add_shortcode('dragblock.post.author.avatar.src', 'dragblock_shortcode_post_author_avatar_src');
function dragblock_shortcode_post_author_avatar_src($attrs)
{
    $post_id = dragblock_get_current_list_query_id();

    if ($post_id === null) {
        return '';
    }
    // Get the author ID of the post
    $author_id = get_post_field('post_author', $post_id);

    // Get the author avatar source
    $avatar_src = get_avatar_url($author_id);

    // Output the author avatar
    return esc_url($avatar_src);
}


add_shortcode('dragblock.post.cat.name', 'dragblock_shortcode_post_cat_name');
function dragblock_shortcode_post_cat_name($attrs)
{
    $post_id = dragblock_get_current_list_query_id();

    if ($post_id === null) {
        return '';
    }


    $categories = get_the_category($post_id);


    if (!empty($categories)) {
        /**
         * @var $category WP_Term
         */
        foreach ($categories as $category) {
            if ($category->category_parent === 0) {
                return $category->name;
            }
        }
    }

    return ''; // Return null if no parent category is found
}
add_shortcode('dragblock.post.cat.url', 'dragblock_shortcode_post_cat_url');
function dragblock_shortcode_post_cat_url($attrs)
{
    $post_id = dragblock_get_current_list_query_id();

    if ($post_id === null) {
        return '';
    }


    $categories = get_the_category($post_id);


    if (!empty($categories)) {
        /**
         * @var $category WP_Term
         */
        foreach ($categories as $category) {
            if ($category->category_parent === 0) {
                return esc_url(get_category_link($category->term_id));
            }
        }
    }

    return '#empty_cat_id'; // Return null if no parent category is found
}


add_shortcode('dragblock.post.cat.id', 'dragblock_shortcode_post_cat_id');
function dragblock_shortcode_post_cat_id($attrs)
{
    $post_id = dragblock_get_current_list_query_id();

    if ($post_id === null) {
        return '';
    }


    $categories = get_the_category($post_id);


    if (!empty($categories)) {
        /**
         * @var $category WP_Term
         */
        foreach ($categories as $category) {
            if ($category->category_parent === 0) {
                return $category->term_id;
            }
        }
    }

    return -1;
}

// add_shortcode('dragblock.query', 'dragblock_shortcode_query');
// function dragblock_shortcode_query($attrs)
// {
//     global $dragBlockQueries;
//     global $dragBlockCurListQueryId;
//     global $dragBlockCurListQueryIdItem;


//     if (empty($dragBlockQueries)) {
//         global $wp_query;
//         $dragBlockCurListQueryId = 'default';

//         $dragBlockQueries[$dragBlockCurListQueryId] = array();
//         foreach ($wp_query->posts as $post) {
//             array_push($dragBlockQueries[$dragBlockCurListQueryId], $post->ID);
//         }
//     }
//     $slug = $attrs['the_query_slug'];
//     $id = $attrs['the_query_id'];
//     unset($attrs['the_query_slug']);
//     unset($attrs['the_query_id']);

//     // listing queries
//     if (in_array($slug, array('WP_Query'))) {
//         $dragBlockCurListQueryId = $id;
//         $args = array(
//             'fields' => 'ids',
//         );

//         foreach ($attrs as $key => $val) {
//             // array attributes
//             if (strpos($key, '__') !== false) {
//                 $args[$key] = explode(',', $val);
//                 continue;
//             }
//             $args[$key] = $val;
//         }

//         if ($slug === 'WP_Query') {
//             $dragBlockQueries[$dragBlockCurListQueryId] = new WP_Query($args);
//             $dragBlockQueries[$dragBlockCurListQueryId] = $dragBlockQueries[$dragBlockCurListQueryId]->posts;
//         }
//     }

//     // other queries
//     if ($slug === 'parse_item') {
//         if (!empty($attrs['query_id'])) {
//             $dragBlockCurListQueryId = $attrs['query_id'];
//         }
//         if (!empty($attrs['item_index'])) {
//             $dragBlockCurListQueryIdItem = intval($attrs['item_index']);
//         } else {
//             if ($dragBlockCurListQueryIdItem === null) {
//                 $dragBlockCurListQueryIdItem = 0;
//             } else {
//                 $dragBlockCurListQueryIdItem++;
//             }
//         }
//     }

//     return '';
// }




/**
 * https://blog.shahednasser.com/how-to-easily-add-share-links-for-each-social-media-platform/#facebook
 */
add_shortcode('dragblock.share.url.twitter', 'dragblock_shortcode_share_url_twitter');
function dragblock_shortcode_share_url_twitter($attrs)
{
    return 'https://twitter.com/intent/tweet?text=' . esc_url($_SERVER['REQUEST_URI']);
}
add_shortcode('dragblock.share.url.facebook', 'dragblock_shortcode_share_url_facebook');
function dragblock_shortcode_share_url_facebook($attrs)
{
    return 'https://www.facebook.com/sharer/sharer.php?u=' . esc_url($_SERVER['REQUEST_URI']);
}
add_shortcode('dragblock.share.url.whatsapp', 'dragblock_shortcode_share_url_whatsapp');
function dragblock_shortcode_share_url_whatsapp($attrs)
{
    return 'https://wa.me/?text=' . esc_url($_SERVER['REQUEST_URI']);
}
add_shortcode('dragblock.share.url.telegram', 'dragblock_shortcode_share_url_telegram');
function dragblock_shortcode_share_url_telegram($attrs)
{
    return 'https://t.me/share/url?url=' . esc_url($_SERVER['REQUEST_URI']);
}
add_shortcode('dragblock.share.url.tumblr', 'dragblock_shortcode_share_url_tumblr');
function dragblock_shortcode_share_url_tumblr($attrs)
{
    return 'https://www.tumblr.com/widgets/share/tool?canonicalUrl=' . esc_url($_SERVER['REQUEST_URI']);
}
add_shortcode('dragblock.share.url.reddit', 'dragblock_shortcode_share_url_reddit');
function dragblock_shortcode_share_url_reddit($attrs)
{
    return 'https://www.reddit.com/submit?url=' . esc_url($_SERVER['REQUEST_URI']);
}
add_shortcode('dragblock.share.url.linkedin', 'dragblock_shortcode_share_url_linkedin');
function dragblock_shortcode_share_url_linkedin($attrs)
{
    return 'https://www.linkedin.com/sharing/share-offsite/?url=' . esc_url($_SERVER['REQUEST_URI']);
}
add_shortcode('dragblock.share.url.gmail', 'dragblock_shortcode_share_url_gmail');
function dragblock_shortcode_share_url_gmail($attrs)
{
    return 'https://mail.google.com/mail/u/0/?view=cm&fs=1&tf=1&body=' . esc_url($_SERVER['REQUEST_URI']);
}
add_shortcode('dragblock.share.url.email', 'dragblock_shortcode_share_url_email');
function dragblock_shortcode_share_url_email($attrs)
{
    return 'mailto:?body=' . esc_url($_SERVER['REQUEST_URI']);
}
add_shortcode('dragblock.share.url.navigator', 'dragblock_shortcode_share_url_navigator');
function dragblock_shortcode_share_url_navigator($attrs)
{
    return 'javascript:navigator.share?navigator.share({url:location.href}):null';
}


/*
When apply shortcode callbacks for html tags,
WordPress will eliminate all protocols that are not in its supported list
So to keep something like data:image/png;base64, or javascript:...
We have to update the supported protocols
*/
add_filter('kses_allowed_protocols', 'dragblock_kses_allowed_protocols', 1);
function dragblock_kses_allowed_protocols($protocols)
{
    $protocols[] = 'data';
    $protocols[] = 'javascript';
    return $protocols;
}

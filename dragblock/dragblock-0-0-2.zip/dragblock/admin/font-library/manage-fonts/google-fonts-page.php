<?php
if ( ! defined( 'ABSPATH' ) ) exit;
require_once( dirname( __DIR__ ) . '/class-react-app.php' );

class DragBlock_Google_Fonts {
	public static function google_fonts_admin_page() {
		DragBlock_React_App::bootstrap();
		?>
		<input id="nonce" type="hidden" value="<?php echo esc_attr(wp_create_nonce( 'dragblock_font_library' )); ?>" />
		<div id="dragblock-font-library-app"></div>

		<?php
	}
}

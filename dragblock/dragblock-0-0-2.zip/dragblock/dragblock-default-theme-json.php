<?php
if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * ****************************************************************
 * At this time, we want stop apply this to not interfere with theme authors
 * For example, if author enabled the default palette and his users
 * are familiar with the tool, then they will get frustrated when
 * the tool is disabled via our plugin
 * 
 * But because the back-end code is heavily depending on the theme colors and layout
 * So we decided provide only those things instead of disabling toolbar or palette
 * ****************************************************************
 * 
 * https://developer.wordpress.org/block-editor/how-to-guides/themes/theme-json/
 * Provide basic theme settings if the current theme has not
 * @var $theme_json WP_Theme_JSON_Data
 */
global $dragblock_update_theme_json;
$dragblock_update_theme_json = null;

// Read the contents of the JSON file
// Convert the JSON data to an array
define('DRAG_BLOCK_DEFAULT_THEME_JSON', json_decode(file_get_contents(dragblock_url('dragblock-default-theme.json')), true));

// var_dump(DRAG_BLOCK_DEFAULT_THEME_JSON);

add_filter('wp_theme_json_data_theme', 'dragblock_default_theme_json', 1);
function dragblock_default_theme_json($theme_json)
{
    global $dragblock_update_theme_json;
    if (!empty($dragblock_update_theme_json)) {
        return $theme_json->update_with($dragblock_update_theme_json);
    }

    $dragblock_update_theme_json = $theme_json->get_data();

    $dragblock_update_theme_json = dragblock_theme_json_merge($dragblock_update_theme_json, DRAG_BLOCK_DEFAULT_THEME_JSON);
    
    if (
        empty($dragblock_update_theme_json['settings']['color']['palette']['theme']) &&
        !empty(DRAG_BLOCK_DEFAULT_THEME_JSON['settings']['color']['palette'])
    ) {
        $dragblock_update_theme_json['settings']['color']['palette']['theme'] =
            DRAG_BLOCK_DEFAULT_THEME_JSON['settings']['color']['palette'];
    }
    // ------------------------------------------------------------------------------------------------
    // this is for showing default css of this plugin so user could change by themeself
    // however, we disabled it for now to simplify the working flow    
    // ------------------------------------------------------------------------------------------------
    if (DRAG_BLOCK_CUSTOM_DEFAULT_STYLE) {
        if (empty($dragblock_update_theme_json['styles']['css'])) {
            $dragblock_update_theme_json['styles']['css'] = '';
        }
        $dragblock_update_theme_json['styles']['css'] .= '/* START: CSS OF DRAGBLOCK */' . file_get_contents(dragblock_url('build/applications/front/style-index.css')) . '/* END: CSS OF DRAGBLOCK */';
    }



    $dragblock_update_theme_json = apply_filters('dragblock_default_theme_json', $dragblock_update_theme_json);

    return $theme_json->update_with($dragblock_update_theme_json);
}
